﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestWebApp
{
    public static class Constants
    {
        public static string Issuer = "assignmnent.test.com";

        public static string SecretKey = "12b6fb24-adb8-4ce5-aa49-79b265ebf256";

        public static string AuthCookie = "authorize.Cookie";
    }
}
